#ifndef GAUSSIANBLUR_H
#define GAUSSIANBLUR_H

#include "GaussianBlur.h"

class GaussianBlur : public ImpBrush
{
public:
	GaussianBlur(ImpressionistDoc* pDoc = NULL, char* name = NULL);

	void BrushBegin(const Point source, const Point target);
	void BrushMove(const Point source, const Point target);
	void BrushEnd(const Point source, const Point target);
	void SetColor(const Point source);
	char* BrushName(void);
};

#endif