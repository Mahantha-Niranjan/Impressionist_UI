//
// ScatteredLine.h
//
// The header file for Line Brush. 
//

#ifndef SCATTEREDLINE_H
#define SCATTEREDLINE_H

#include "LineBrush.h"


class ScatteredLine : public LineBrush
{
public:
	ScatteredLine( ImpressionistDoc* pDoc = NULL, char* name = NULL );

	void BrushBegin( const Point source, const Point target );
	void BrushMove( const Point source, const Point target );
	void BrushEnd( const Point source, const Point target );
	char* BrushName( void );
};

#endif