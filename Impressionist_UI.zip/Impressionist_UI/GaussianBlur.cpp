#include "impressionistDoc.h"
#include "impressionistUI.h"
#include "GaussianBlur.h"

extern float frand();

GaussianBlur::GaussianBlur(ImpressionistDoc* pDoc, char* name) :
ImpBrush(pDoc, name)
{
}

void GaussianBlur::BrushBegin(const Point source, const Point target)
{
	ImpressionistDoc* pDoc = GetDocument();
	ImpressionistUI* dlg = pDoc->m_pUI;
	BrushMove(source, target);
}

void GaussianBlur::SetColor(const Point source) {

	ImpressionistDoc* pDoc = GetDocument();
	ImpressionistUI* dlg = pDoc->m_pUI;
	int gtarget = 0;

	GLdouble GaussianKernel[9] =
	{	0.0625, 0.125, 0.0625,
		0.125, 0.25, 0.125,
		0.0625, 0.125, 0.0625,
	};

	GLfloat redColor = 0.0;
	GLfloat greenColor = 0.0;
	GLfloat blueColor = 0.0;
	
	GLubyte tempColor[3];
	GLubyte color[3];

	GLfloat colors[3];
	GLfloat tempcolors[3];


	for (int i = -2; i <= 1; i += 1)
	{
		for (int j = -2; j <= 1; j += 1) 
		{
			memcpy(tempColor, pDoc->GetOriginalPixel(source.x + i, source.y + j), 3);
	
			for (int k = 0; k < 3; k++)
			{
				tempcolors[k] = (float)tempColor[k];
			}

			redColor += tempcolors[0] * GaussianKernel[gtarget];
			greenColor += tempcolors[1] * GaussianKernel[gtarget];
			blueColor += tempcolors[2] * GaussianKernel[gtarget];
		}
	}

	if (redColor > 255) 
	{
		redColor = 255;
	}
	if (redColor < 0)
	{
		redColor = 0;
	}
	if (greenColor > 255)
	{
		greenColor = 255;
	}
	if (greenColor < 0) 
	{
		greenColor = 0;
	}
	if (blueColor > 255)
	{ 
		blueColor = 255;	
	}
	if (blueColor < 0)
	{
		blueColor = 0;
	}

	colors[0] = redColor;
	colors[1] = greenColor;
	colors[2] = blueColor;
	color[0] = (GLubyte)colors[0];
	color[1] = (GLubyte)colors[1];
	color[2] = (GLubyte)colors[2];

	glColor3ubv(color);
}

void GaussianBlur::BrushMove(const Point source, const Point target)
{
	ImpressionistDoc* pDoc = GetDocument();
	ImpressionistUI* dlg = pDoc->m_pUI;

	if (pDoc == NULL) {
		printf("GaussianBlur::BrushMove  document is NULL\n");
		return;
	}

	int size = pDoc->getSize();

	glPointSize(0.5);

	glBegin(GL_POINTS);

	for (int l = -size / 2; l <= size / 2; l++) 
	{
		for (int m = -size / 2; m <= size / 2; m++) 
		{
			SetColor(Point(source.x + l, source.y + m));
			glVertex2d(target.x + l, target.y + m);
		}
	}

	glEnd();
}

void GaussianBlur::BrushEnd(const Point source, const Point target)
{
}
