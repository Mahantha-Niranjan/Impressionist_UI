#include "impressionistDoc.h"
#include "impressionistUI.h"
#include "RandomTriangle.h"

extern float frand();

RandomTriangle::RandomTriangle( ImpressionistDoc* pDoc, char* name ) :
	ImpBrush(pDoc,name)
{
}

void RandomTriangle::BrushBegin( const Point source, const Point target )
{
	ImpressionistDoc* pDoc = GetDocument();
	ImpressionistUI* dlg=pDoc->m_pUI;

	int size = pDoc->getSize();



	glPointSize( (float)size );

	BrushMove( source, target );
}

void RandomTriangle::BrushMove( const Point source, const Point target )
{
	ImpressionistDoc* pDoc = GetDocument();
	ImpressionistUI* dlg=pDoc->m_pUI;

	if ( pDoc == NULL ) {
		printf( "RandomTriangle::BrushMove  document is NULL\n" );
		return;
	}

	float alphavalue = pDoc->getAlphaValue();
	int size = pDoc->getSize();

	glBegin( GL_TRIANGLE_FAN );
		SetColor( source, alphavalue);

		int random=rand()%10+6;
		
		glVertex2d( target.x, target.y );
		glVertex2d( target.x-random, target.y-random );
		glVertex2d( target.x+random, target.y-random );

	glEnd();
}

void RandomTriangle::BrushEnd( const Point source, const Point target )
{
	// do nothing so far
}

