#include "impressionistDoc.h"
#include "impressionistUI.h"
#include "DirectionStroke.h"
#include "string.h"
#include <cmath>
extern float frand();

DirectionStroke::DirectionStroke( ImpressionistDoc* pDoc, char* name ) :
	ImpBrush(pDoc,name)
{
}

void DirectionStroke::BrushBegin( const Point source, const Point target )
{
	ImpressionistDoc* pDoc = GetDocument();
	ImpressionistUI* dlg=pDoc->m_pUI;

	int size = pDoc->getSize();
	int width = pDoc->getLineWidth();
	glLineWidth(width);
	
	int alpha = pDoc->getAlphaValue();

	glPointSize( (float)size );
	glLineWidth((float) width);

	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	BrushMove( source, target );
}

void DirectionStroke::BrushMove( const Point source, const Point target )
{
	ImpressionistDoc* pDoc = GetDocument();
	ImpressionistUI* dlg=pDoc->m_pUI;
	int angle = pDoc->getLineAngle();
	float size = pDoc->getSize();
	float alphavalue = pDoc->getAlphaValue();
	angle= 0;

	int strokeChoice= dlg->m_StrokeChoice->value();

	if ( pDoc == NULL ) {
		printf( "DirectionStroke::BrushMove  document is NULL\n" );
		return;
	}

	switch (strokeChoice)
	{
	case BRUSH_DIRECTION:
		angle = pDoc->getLineAngle();
		break;
	default:
		break;
	}

			glBegin(GL_LINES);
			SetColor(source, alphavalue);
				glVertex2d(target.x, target.y);
				glVertex2d(target.x+10, target.y);

			glEnd();
			
}

void DirectionStroke::BrushEnd( const Point source, const Point target )
{
	// do nothing so far
}

