//
// ScatteredLine.cpp
//
// The implementation of Point Brush. It is a kind of ImpBrush. All your brush implementations
// will look like the file with the different GL primitive calls.
//

#include "impressionistDoc.h"
#include "impressionistUI.h"
#include "ScatteredLine.h"
#include<cmath>

extern float frand();

ScatteredLine::ScatteredLine( ImpressionistDoc* pDoc, char* name ) :
	LineBrush(pDoc,name)
{
}

void ScatteredLine::BrushBegin( const Point source, const Point target )
{
	ImpressionistDoc* pDoc = GetDocument();
	ImpressionistUI* dlg=pDoc->m_pUI;

	int size = pDoc->getSize();
	int width = pDoc->getLineWidth();
	glLineWidth(width);

	BrushMove( source, target );
}

void ScatteredLine::BrushMove( const Point source, const Point target )
{
	ImpressionistDoc* pDoc = GetDocument();
	ImpressionistUI* dlg=pDoc->m_pUI;

	if ( pDoc == NULL ) {
		printf( "ScatteredLine::BrushMove  document is NULL\n" );
		return;
	}

		int size = pDoc->getSize();	
		int no_lines = 5;
		float alphavalue = pDoc->getAlphaValue();
		int angle = pDoc->getLineAngle();

		for (int i = 0; i < no_lines; i++) 
		{
			int xproj_rand = rand() % size + (-size / 2);
			int yproj_rand = rand() % size + (-size / 2);
		
			int SourceX = source.x + xproj_rand;
			int SourceY = source.y + yproj_rand;
			int TargetX = target.x + xproj_rand;
			int TargetY = target.y + yproj_rand;

			Point Source(SourceX, SourceY);
			Point Target(TargetX, TargetY);

		LineBrush::BrushMove(Source, Target);
		}
}


void ScatteredLine::BrushEnd( const Point source, const Point target )
{
	// do nothing so far
}

