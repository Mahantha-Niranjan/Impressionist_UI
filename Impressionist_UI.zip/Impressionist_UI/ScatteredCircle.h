#ifndef SCATTEREDCIRCLE_H
#define SCATTEREDCIRCLE_H

#include "CircleBrush.h"

class ScatteredCircle : public CircleBrush
{
public:
	ScatteredCircle( ImpressionistDoc* pDoc = NULL, char* name = NULL );

	void BrushBegin( const Point source, const Point target );
	void BrushMove( const Point source, const Point target );
	void BrushEnd( const Point source, const Point target );
	char* BrushName( void );
};

#endif