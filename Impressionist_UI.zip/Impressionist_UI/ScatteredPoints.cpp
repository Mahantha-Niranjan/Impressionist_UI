#include "impressionistDoc.h"
#include "impressionistUI.h"
#include "ScatteredPoints.h"

extern float frand();

ScatteredPoints::ScatteredPoints( ImpressionistDoc* pDoc, char* name ) :
	ImpBrush(pDoc,name)
{
}

void ScatteredPoints::BrushBegin( const Point source, const Point target )
{
	ImpressionistDoc* pDoc = GetDocument();
	ImpressionistUI* dlg=pDoc->m_pUI;

	int size = pDoc->getSize();



	glPointSize( (float)1);

	BrushMove( source, target );
}

void ScatteredPoints::BrushMove( const Point source, const Point target )
{
	ImpressionistDoc* pDoc = GetDocument();
	ImpressionistUI* dlg=pDoc->m_pUI;

	if ( pDoc == NULL ) {
		printf( "ScatteredPoints::BrushMove  document is NULL\n" );
		return;
	}

	int size = pDoc->getSize();
	float alphavalue = pDoc->getAlphaValue();

		glBegin( GL_POINTS );
		SetColor( source, alphavalue );

		for(int i=0; i< 20; i++)
		{
			int random = rand() % 15 + 1;
			glVertex2d(target.x + frand() * size/2, target.y + frand() * size/2 );
		}
		glEnd();
}

void ScatteredPoints::BrushEnd( const Point source, const Point target )
{
	// do nothing so far
}

