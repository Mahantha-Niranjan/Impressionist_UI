//
// LineBrush.cpp
//
// The implementation of Point Brush. It is a kind of ImpBrush. All your brush implementations
// will look like the file with the different GL primitive calls.
//

#include "impressionistDoc.h"
#include "impressionistUI.h"
#include "LineBrush.h"
#include "math.h"

extern float frand();

LineBrush::LineBrush( ImpressionistDoc* pDoc, char* name ) :
	ImpBrush(pDoc,name)
{
}

void LineBrush::BrushBegin( const Point source, const Point target )
{
	ImpressionistDoc* pDoc = GetDocument();
	ImpressionistUI* dlg=pDoc->m_pUI;

	int width = pDoc->getLineWidth();
	glLineWidth(width);
	
	BrushMove( source, target );
}

void LineBrush::BrushMove( const Point source, const Point target )
{
	ImpressionistDoc* pDoc = GetDocument();
	ImpressionistUI* dlg=pDoc->m_pUI;
	int angle = pDoc->getLineAngle();
	int size=pDoc->getSize();

	int hsize= size/2;
	float alphavalue = pDoc->getAlphaValue();

	int center_t1=hsize;
	int center_t2=hsize;

	if ( pDoc == NULL ) {
		printf( "LineBrush::BrushMove  document is NULL\n" );
		return;
	}

	double cosxproj= cos(angle * M_PI/ 180.0);
	double sinyproj= sin(angle * M_PI/ 180.0);

	int startX= target.x-cosxproj * center_t1;
	int startY= target.y-sinyproj * center_t1;
	int endX= target.x+cosxproj * center_t2;
	int endY= target.y+sinyproj * center_t2;

	glBegin( GL_LINES );
	SetColor( source, alphavalue);

		glVertex2d( startX, startY);
		glVertex2d( endX, endY);

	glEnd();
}

void LineBrush::BrushEnd( const Point source, const Point target )
{
	// do nothing so far
}

