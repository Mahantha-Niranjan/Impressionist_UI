#include "impressionistDoc.h"
#include "impressionistUI.h"
#include "ScatteredCircle.h"
#include<cmath> 

extern float frand();

ScatteredCircle::ScatteredCircle( ImpressionistDoc* pDoc, char* name ) :
	CircleBrush(pDoc,name)
{
}

void ScatteredCircle::BrushBegin( const Point source, const Point target )
{
	ImpressionistDoc* pDoc = GetDocument();
	ImpressionistUI* dlg=pDoc->m_pUI;

	BrushMove( source, target );
}

void ScatteredCircle::BrushMove( const Point source, const Point target )
{
	ImpressionistDoc* pDoc = GetDocument();
	ImpressionistUI* dlg=pDoc->m_pUI;

	if ( pDoc == NULL ) {
		printf( "PointBrush::BrushMove  document is NULL\n" );
		return;
	}

	int size = pDoc->getSize();
	int no_circle = 5;
	

	for (int i = 1; i < no_circle; i++) 
	{
		int randx = (-size / 2)+rand() % size+5;
		int randy = (-size / 2)+rand() % size;

		Point Source(source.x + randx, source.y + randy);
		Point Target(target.x + randy, target.y + randx);

		CircleBrush::BrushMove(Source, Target);
	}

}

void ScatteredCircle::BrushEnd( const Point source, const Point target )
{
	// do nothing so far
}

