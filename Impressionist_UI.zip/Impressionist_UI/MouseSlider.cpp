#include "impressionistDoc.h"
#include "impressionistUI.h"
#include "MouseSlider.h"
#include "string.h"
#include <cmath>
extern float frand();

MouseSlider::MouseSlider( ImpressionistDoc* pDoc, char* name ) :
	ImpBrush(pDoc,name)
{
}

void MouseSlider::BrushBegin( const Point source, const Point target )
{
	ImpressionistDoc* pDoc = GetDocument();
	ImpressionistUI* dlg=pDoc->m_pUI;

	int size = pDoc->getSize();
	int width = pDoc->getLineWidth();
	glLineWidth(width);
	
	int alpha = pDoc->getAlphaValue();

	glPointSize( (float)size );
	glLineWidth((float) width);

	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	prePoint=Point(target);
	BrushMove( source, target );
}

void MouseSlider::BrushMove( const Point source, const Point target )
{
	ImpressionistDoc* pDoc = GetDocument();
	ImpressionistUI* dlg=pDoc->m_pUI;
	int angle = pDoc->getLineAngle();
	float size = pDoc->getSize();
	float alphavalue = pDoc->getAlphaValue();
	angle= 0;

	int strokeChoice= dlg->m_StrokeChoice->value();

	if ( pDoc == NULL ) {
		printf( "MouseSlider::BrushMove  document is NULL\n" );
		return;
	}

	int diffX = target.x - prePoint.x;
			int diffY = target.y - prePoint.y;
			
			angle = (int)(atan2(diffY, diffX) / M_PI * 360); 

			int halfSize = size / 2;
			double cosineProj = cos(angle * M_PI / 180.0);
			double sineProj = sin(angle * M_PI / 180.0);

			int centerToTarget1 = halfSize;
			int centerToTarget2 = halfSize;


	switch (strokeChoice)
	{
	case SLIDER:
		angle = pDoc->getLineAngle();
		break;
	default:
		break;
	}

			int startPointX = target.x - cosineProj  * centerToTarget1;
			int startPointY = target.y - sineProj * centerToTarget1;
			int endPointX = target.x + cosineProj * centerToTarget2;
			int endPointY = target.y + sineProj * centerToTarget2;
			int x1 = target.x - lineProjX / 2;
			int y1 = target.y - lineProjY / 2;
			int x2 = target.x + lineProjX / 2;
			int y2 = target.y + lineProjY / 2;

			glBegin(GL_LINES);
			SetColor(source, alphavalue);

				glVertex2d(startPointX, startPointY);
				glVertex2d(endPointX, endPointY);

			glEnd();
			
}

void MouseSlider::BrushEnd( const Point source, const Point target )
{
	// do nothing so far
}

